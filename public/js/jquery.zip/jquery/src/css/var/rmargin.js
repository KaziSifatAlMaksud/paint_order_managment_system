
define(function() {
	return (/^margin/);
});
