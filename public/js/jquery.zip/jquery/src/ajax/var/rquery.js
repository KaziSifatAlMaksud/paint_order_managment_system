
define(function() {
	return (/\?/);
});


